package com.example.a3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button button,exit,one,two,three;
    private TextView text1,text;
    private EditText edittext;
    int number1 = (int) (Math.random() * 100);
    int number2 = (int) (Math.random() * 50);
    int number3 = (int) (Math.random() * 25);
    int tek=1;
    String s,w;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text1 = (TextView) findViewById(R.id.text1);
        text = (TextView) findViewById(R.id.text);
        edittext = (EditText) findViewById(R.id.edittext);
        button = (Button) findViewById(R.id.button);
        button.setOnClickListener(clickListener1);
        exit = (Button) findViewById(R.id.exit);
        exit.setOnClickListener(clickListener2);
        one = (Button) findViewById(R.id.one);
        one.setOnClickListener(clickListener3);
        two = (Button) findViewById(R.id.two);
        two.setOnClickListener(clickListener4);
        three = (Button) findViewById(R.id.three);
        three.setOnClickListener(clickListener5);
    }
    View.OnClickListener clickListener1 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (tek==3){
                w="Попробуйте угадать число от 0 до 100";
                text.setText(w.toCharArray(),0, w.length());
                if (edittext.getText().length() > 0){
                    String a = edittext.getText().toString();
                    int q = Integer.parseInt(a);
                    if (q<0 | q>100){
                        s="Что-то не так с числом";
                    }
                    else if (q>number1){
                        s="Загаданное число меньше ";
                    }
                    else if (q<number1){
                        s="Загаданное число больше ";
                    }
                    else if (q==number1){
                        s="Ура, победа!";
                        number1 = (int) (Math.random() * 100);
                    }
                    edittext.getText().clear();
                }
                else {
                    s="Введите число!!!";
                }
                text1.setText(s.toCharArray(),0, s.length());
            }
            else if (tek==1){
                w="Попробуйте угадать число от 0 до 25";
                text.setText(w.toCharArray(),0, w.length());
                if (edittext.getText().length() > 0){
                    String a = edittext.getText().toString();
                    int q = Integer.parseInt(a);
                    if (q<0 | q>25){
                        s="Что-то не так с числом";
                    }
                    else if (q>number3){
                        s="Загаданное число меньше ";
                    }
                    else if (q<number3){
                        s="Загаданное число больше ";
                    }
                    else if (q==number3){
                        s="Ура, победа!";
                        number3 = (int) (Math.random() * 25);
                    }
                    edittext.getText().clear();
                }
                else {
                    s="Введите число!!!";
                }
                text1.setText(s.toCharArray(),0, s.length());
            }
            else if (tek==2){
                w="Попробуйте угадать число от 0 до 50";
                text.setText(w.toCharArray(),0, w.length());
                if (edittext.getText().length() > 0){
                    String a = edittext.getText().toString();
                    int q = Integer.parseInt(a);
                    if (q<0 | q>50){
                        s="Что-то не так с числом";
                    }
                    else if (q>number2){
                        s="Загаданное число меньше ";
                    }
                    else if (q<number2){
                        s="Загаданное число больше ";
                    }
                    else if (q==number2){
                        s="Ура, победа!";
                        number2 = (int) (Math.random() * 50);
                    }
                    edittext.getText().clear();
                }
                else {
                    s="Введите число!!!";
                }
                text1.setText(s.toCharArray(),0, s.length());
            }
        }
    };

    View.OnClickListener clickListener3 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            tek=1;
            w="Попробуйте угадать число от 0 до 25";
            text.setText(w.toCharArray(),0, w.length());
            s="Загадано новое число";
            text1.setText(s.toCharArray(),0, s.length());
        }
    };
    View.OnClickListener clickListener4 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            tek=2;
            w="Попробуйте угадать число от 0 до 50";
            text.setText(w.toCharArray(),0, w.length());
            s="Загадано новое число";
            text1.setText(s.toCharArray(),0, s.length());
        }
    };
    View.OnClickListener clickListener5 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            tek=3;
            w="Попробуйте угадать число от 0 до 100";
            text.setText(w.toCharArray(),0, w.length());
            s="Загадано новое число";
            text1.setText(s.toCharArray(),0, s.length());
        }
    };
    View.OnClickListener clickListener2 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            System.exit(1);
        }
    };
}